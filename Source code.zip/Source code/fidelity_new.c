v3 = *((_BYTE**)(a1 + 872)); //I1 Pointer arithmetic to access struct references
v3[1] = a2; //I1 Array access to access struct members
v10 = v7(v6, v11, (*((_DWORD*)(a1 + 4))) - v11); //I1 Pointer arithmetic to access struct members
++(*((_DWORD*)(a1 + 16))); //I1 Pointer arithmetic to access struct members
result = bsplitcb(a1, *(*((_BYTE**)(a2 + 8))), a3, a4, a5); //I1 Pointer arithmetic to access struct members
*((_DWORD*)(result + 4)) = a2; //I1 Pointer arithmetic to access struct members
if ((a2 < 0) || (a2 >= (*((_DWORD*)(a1 + 20))))) //I1 Pointer arithmetic to access struct members
if (!((_DWORD)result)) //I1 Pointer arithemtic to access struct members
free(*((void**)(a1 + 16))); //I1 Pointer arithmetic to access struct members
*((double*)((a1 + (280LL * v5)) + 272)) = a3; //I1 Pointer arithmetic to access array members, Pointer arithmetic to access struct members
*((_DWORD*)(a1 + 12)) = 0; //I1 Pointer arithmetic to access struct members
if (!(*((_DWORD*)(a2 + 44)))) //I1 Pointer arithmetic to access struct members
i += *((_DWORD*)(a2 + 4)); //I1 Pointer arithmetic to access struct members
for (i = 0; i < (*((_DWORD*)(a1 + 16))); ++i) //I1 Pointer arithmetic to access struct members
if ((a1[5] < 0) || (a1[5] > a1[4])) //I1 Array access to access struct members
v11 = v9 - ((unsigned long long) (*((unsigned int*)(a2 + 20)))); //I1 Pointer arithmetic to access struct members
if (*((_QWORD*)(v2 + 32))) //I1 Pointer arithmetic to access struct members
result = *((signed short*)(((*((_QWORD*)(a2 + 8))) + (120LL * (a1 >> 3))) + 52)); //I1 Pointer arithmetic to access struct members, Pointer dereference to access array members
p_free(*((_QWORD*)(a1 + 24))); //I1 Pointer arithmetic to access struct members
v3[1] = 0LL; //I1 Array access to access struct members
*((_DWORD*)((*((_QWORD*)a2)) + 28LL)) = 6; //I1 Pointer dereference to access struct member
for (j = a3; j < (*((_DWORD*)(a1 + 4))); ++j) //I1 Pointer arithmetic to access struct members
*((_QWORD*)(i + 64)) = *((_QWORD*)((*((_QWORD*)(i + 64))) + 64LL)); //I1 Pointer arithmetic to access struct members
v12 = *((_DWORD*)(a2 + 32)); //I1 Pointer arithmetic to access struct members
v5 = (*((_DWORD*)(a1 + 4480)))++; //I1 Pointer arithmetic to access struct members
*((_QWORD*)((*((_QWORD*)(a1 + 32))) + 64LL)) = a2; //I1 Pointer arithmetic to access struct members
*v3 = malloc(a2); //I1 Pointer dereference to access first struct member
v1[2] = 0; //I1 Array access to access struct members
if ((a1[4] <= 7) || (a1[4] > 128)) //I1 Array access to access struct members
return *((_QWORD*)((*((_QWORD*)(a1 + 24))) + (8LL * ((*((_DWORD*)(a1 + 8))) + a2)))); //I1 Pointer arithmetic to access struct members
*v3 = ft_memmove(*v3, a1, a2); //I1 Pointer dereference to access first struct member
result = *((unsigned int*)(*a1)); //I1 Pointer dereference to access first struct member
*a1 = v2; //I1 Pointer dereference to access first struct member
*((_DWORD*)((280LL * v5) + a1)) = 6579570; //I1  Pointer arithmetic to access struct members
v0[12] = 0LL; //I1 Array access to access struct members
ptr = *((void***)(a1 + 8)); //I1 Pointer arithmetic as struct dereference
--(*((_DWORD*)(*a1)));  //I1 Pointer dereference to access first struct member
if (!memcmp(*((const void**)(a2 + 8)), (const void*)(i + (*((_QWORD*)(a1 + 8)))), *((signed int*)(a2 + 4)))) //I1 Pointer arithmetic to access struct members
return (*((_QWORD*)a2)) + (8LL * (v7 - (*((_DWORD*)(a2 + 28))))); //I1 Pointer arithmetic to access struct members
*((_BYTE*)((i - 1LL) + a2)) = 0; //I1  Pointer arithmetic to access array members, Character literals as integers
if ((((a3 + a4) > (*((_DWORD*)(a2 + 8)))) || (a4 > (*((_DWORD*)(a2 + 16))))) || (!(*((_QWORD*)a2)))) //I1 Pointer arithmetic to access struct members
result = *((unsigned int*)(a1 + 236)); //I1 Pointer arithmetic to access struct members
*((_DWORD*)(a2 + 28)) = v11; //I1 Pointer arithmetic to access struct members
a1[797] = 0LL; //I1 Array access to access struct members
n = ((unsigned long long) (*((unsigned int*)(a2 + 12)))) << 7; //I1 Pointer arithmetic to access struct members
result = *((_QWORD*)(a1 + 192)); //I1 Pointer arithmetic to access struct members
if (a1[6] >= 0) //I1 Array access to access struct members
a1[796] = malloc(4LL * a2); //I1 Array access to access struct members
a1[1] = v2 + 32; //I1 Array access to access struct members
*(((_BYTE*)v17) + i) ^= *(((_BYTE*)v30) + i); //I1 Pointer arithmetic to access array members
if ((--(*(((_BYTE*)(&z80ex)) + 2))) == 127) //I1 Pointer arithmetic to access struct members
*((_DWORD*)((unsigned int)(a1 + 96))) = result; //I1 Pointer arithemtic to access struct members
if ((*((_DWORD*)(a2 + 4))) == 1) //I1 Pointer arithmetic to access struct members
*(((_BYTE*)v17) + i) = (*(((_BYTE*)v30) + i)) ^ (*(((_BYTE*)v19) + i)); //I1 Pointer arithmetic to access array members
*((_BYTE*)(a1 + 133)) = 1; //I1  Pointer arithmetic to access struct members, Expanded user-defined macros
*((_DWORD*)((4LL * a1) + skns_tilemapA_ram)) = (a3 & (*((_DWORD*)((4LL * a1) + skns_tilemapA_ram)))) | (a2 & (~a3)); //I1 Pointer arithmetic to access array members
ui_text_delete(*((_QWORD*)((8LL * i) + (*((_QWORD*)(a1 + 16)))))); //I1 Pointer arithmetic to access array members
a1[798] = a2; //I1 Array access to access struct members
*(((_BYTE*)v18) + i) ^= *(((_BYTE*)v30) + i); //I1 Pointer arithmetic to access array members
free(*((void**)(((*((_QWORD*)(a1 + 24))) + (136LL * i)) + 112))); //I1 Pointer arithmetic to access struct members
if (*((_DWORD*)(*a1))) //I1 Pointer dereference to access first struct member
result = a2 | (*((_DWORD*)((unsigned int)(a1 + 40)))); //I1 Pointer arithemtic to access struct members
v10 = v9 - (*((_DWORD*)(a2 + 28))); //I1 Pointer arithmetic to access struct members
*v3 = 0LL; //I1 Pointer dereference to access first struct member appears
v13 = v12 - (*((_DWORD*)(a2 + 28))); //I1 Pointer arithmetic to access struct members
if ( *(double *)(24 * j + a1) > v9 ) //I1 Pointer arithmetic to access struct members
v9 = *(double *)(24 * j + a1); //I1 Pointer arithmetic to access struct members
ptr[3 * i] = (double)(3 * (i + 1) % a4) / v18; //I1 Pointer arithmetic to access struct members
*v8 = *a1; //I1 Pointer arithmetic to access struct members
a1[5 * v7 + 6] = a1[1]; //I1 Pointer arithmetic to access struct members
*a1 = -1; //I1 Pointer arithmetic to access struct members
a1[1] = -1; //I1 Pointer arithmetic to access struct members
result = sqlite3CorruptError((int)&loc_10013); //I2 memory address as integers
return 262; //I2 Character literals as integers
if (((*a1) != 47) || (!a1[1])) //I2 Character literals as integers
for (i = *((_QWORD*)(v2 + 16)); *((_QWORD*)(i + 24)); i = *((_QWORD*)(i + 24))) //I2 While loop as non-cannonical for loop
*((_DWORD*)v8) = 538976288; //I2 String literal as single integer
if (((*(*a1)) == 104) || ((result = (unsigned char)(*(*a1)), ((_BYTE)result) == 108))) //I2 Character literal as integer
case 77: //I2 Character literals as integers
*((_QWORD*)v7) = 4702707243111632457LL; //I2 String literal as single integer
case 103: //I2 Character literals as integers
*((_DWORD*)(&optypeTab[strlen(optypeTab)])) = 666749; //I2 String literal as single integer
*((_DWORD*)optypeTab) = 538976288; //I2 String literal as single integer
ERR_GOST_error(129, 111, (int)"gost_pmeth.c", 529); //I2 String literal as single integer
v2 = 63;  //I2 String literal as single integer
s[0] = 94;  //I2 String literal as single integer
putchar(10);  //I2 String literal as single integer
fputc(44, stream);  //I2 String literal as single integer
if ( *(_BYTE *)(v2 + a1) == 45 )  //I2 String literal as single integer
return 0LL;  //I2 String literal as single integer
if ( v13 == 97 )  //I2 String literal as single integer
v13 = malloc(0x28uLL); //I2 single integer
while ( 1 ) // I3 Confused control flow refactoring
if (a1[796]) //I3 Confused control flow refactoring
if ( (((int)v11 >> 4) & 7) != 0 ) //I3 Confused control flow refactoring
return 8 * ((a1 + 4) / 5); //I3 Confused control flow refactoring
for ( i = (char **)xfts_open(a1, a2, 0); ; v7 = (v7 & process_file((int)i, (int)v9)) != 0 ) //I3 Confused control flow refactoring
if (v2 >= 0 || *_errno_location() == 61) //I3 Confused control flow refactoring
const char* v3; //I4 Extraneous variable
result = *a1; //I4 Extra code to initialize extraneous variable
unsigned int v4; //I4 Extraneous variable
unsigned long long result; //I4 Extraneous variable
v3 = a2; //I4  Extra code to initialize extraneous variable
signed int v3;//I4 Extraneous variable
while (((_BYTE)result) != 13); //I4 Extraneous typecast
v2 = v1; //I4  Extra code to initialize extraneous variable
unsigned int v13; //I4 Extraneous variable
result = a1; //I4  Extra code to initialize extraneous variable
result = v18; //I4  Extra code to initialize extraneous variable
result = (double*)((a1 + (280LL * v5)) + 256); //I4 Extra code to initialize extraneous variable
test_machine_init(*((_QWORD*)(&argc)), argv, envp); //I4 Extra arguments, C3.a. Extraneous typecast
v30 = v17; //I4  Extra code to initialize extraneous variable
v6 = a5; //I4  Extra code to initialize extraneous variable
long long result; //I4 Extraneous variable appears
interpret_rtl_and(&t0, (_DWORD*)0x994, ((_DWORD*)(&operand_write)) + 1); //I4 Global variable issues
* result = a4; //I4  Extra code to initialize extraneous variable
v3 = __errno_location(); //I4 Extraneous code
v4 = strerror(*v3); //I4 Extraneous code
return result; //I5 Return value for void function
return fputs_unlocked(v1, stdout);  //I5 Return value for void function
v3 = malloc(8LL * a1); //I6 Expanded standard symbol
v1 = malloc(0x20020uLL); //I6 Expanded standard symbol
v9 = __readgsdword(0x14u); // I6 Expanded standard symbol appears 39 times in retrieve.txt
_assert_fail("image_info != (const ImageInfo *) NULL", "coders/art.c", 0x134u, "WriteARTImage"); // I6 Expanded standard symbol
j_LogMagickEvent((char *)&stru_7FF4.st_info, "MagickCore/blob.c", "DetachBlob", 1035, "..."); // I6 Expanded standard symbol
result = _errno_location(); // I6 Expanded standard symbol
v5[27] = __readgsdword(0x14u); // I6 Expanded standard symbol
BYTE2(v16) ^= BYTE1(v14); // I6 Expanded standard symbol appears
return __readgsdword(0x14u) ^ v9; // I6 Expanded standard symbol
__assert_fail("retkey", "import.c", 0x5A2u, "openssh_new_read"); // I6 Expanded standard symbol
putchar_unlocked(v3); // I6 Expanded standard symbol
fputs_unlocked(ptr, stdout); // I6 Expanded standard symbol
while ( !feof_unlocked(a1) && !ferror_unlocked(a1) && v15 < 0x7800 ); // I6 Expanded standard symbol
if ( ferror_unlocked(a1) ) // I6 Expanded standard symbol
v10 = fwrite_unlocked(ptr, 1u, n, a2); // I6 Expanded standard symbol
return fputc_unlocked(10, (FILE *)stderr); // I6 Expanded standard symbol
LOBYTE(v3) = o_nocache_eof != 0; // I6 Expanded standard symbol
BYTE2(v16) ^= BYTE1(v14); // I6 Expanded standard symbol
LOBYTE(v16) = HIBYTE(v14) ^ v16; // I6 Expanded standard symbol
*a4 = sqlite3CorruptError((int)&loc_1014D); // I6 Expanded standard symbol
sqlite3SelectPrep(s[0], v5, (int)s); // I6 Expanded standard symbol
sqlite3WalkSelect((int)a1, v5); // I6 Expanded standard symbol
c_write(a1, (int)"\b \b", 3); // I6 Expanded standard symbol
v4 = fwrite(ptr, 1u, n, *(FILE **)a1); // I6 Expanded standard symbol
BIO_puts(a1, (int)"subject="); // I6 Expanded standard symbol
v3 = CRYPTO_malloc(v2, (int)"apps.c", 1544); // I6 Expanded standard symbol
ERR_put_error(0xDu, 182, 187, (int)"asn1_gen.c", 399); // I6 Expanded standard symbol
result = CRYPTO_free((int)a1); // I6 Expanded standard symbol
return LODWORD(v5); // I6 Expanded standard symbol
result = j_LogMagickEvent((char *)&stru_7FF4.st_info, "MagickCore/blob.c", "AttachCustomStream", 312, "..."); // I6 Expanded standard symbol